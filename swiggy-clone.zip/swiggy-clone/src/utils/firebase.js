import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";

const firebaseConfig = {
  apiKey: "AIzaSyC5Cp13xxdPUvZ436rA6gb59cJ21N3fRPY",
  authDomain: "auth-1d86b.firebaseapp.com",
  projectId: "auth-1d86b",
  storageBucket: "auth-1d86b.firebasestorage.app",
  messagingSenderId: "487893034064",
  appId: "1:487893034064:web:04d5c780707159467b9d55",
  measurementId: "G-NHRT6SBLDH",
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);

export { auth };
