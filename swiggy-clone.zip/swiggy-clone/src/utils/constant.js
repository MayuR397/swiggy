export const SWIGGY_LOGO = "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSG8CYNfB2vnxcARcGZdqaxP86zQqJxY31VZDfJk_-P4a0jqObhATaZTEQapKX0jgvpfXI&usqp=CAU"

export const DATA_URL = "https://www.swiggy.com/dapi/restaurants/list/v5?lat=12.9358325&lng=77.6328499&is-seo-homepage-enabled=true&page_type=DESKTOP_WEB_LISTING"

export const CDN_URL = "https://media-assets.swiggy.com/swiggy/image/upload/fl_lossy,f_auto,q_auto,w_288,h_360/"