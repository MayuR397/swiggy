import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import Signup from "./components/Signup";
import Login from "./components/Login";
import { ToastContainer, toast } from "react-toastify";
import Home from "./components/Home";
import Navbar from "./components/Navbar";
import ResturantPage from "./components/ResturantPage";
import Cart from "./components/Cart";

function App() {
  return (
    <>
      <ToastContainer position="top-left" autoClose={1000} />
      <Router>
        <Navbar />
        <div className="min-h-screen flex justify-center items-center bg-gray-100">
          <Routes>
            <Route path="/signup" element={<Signup />} />
            <Route path="/login" element={<Login />} />
            <Route path="/home" element={<Home />} />
            <Route path="/home/resturant/:resId" element={<ResturantPage/>}/>
            <Route path="/cart" element={<Cart/>}/>
            {/* Add your other routes here */}
          </Routes>
        </div>
      </Router>
    </>
  );
}

export default App;
