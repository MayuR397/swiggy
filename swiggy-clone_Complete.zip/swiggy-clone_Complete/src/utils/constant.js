export const SWIGGY_LOGO = "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSG8CYNfB2vnxcARcGZdqaxP86zQqJxY31VZDfJk_-P4a0jqObhATaZTEQapKX0jgvpfXI&usqp=CAU"

export const CDN_URL = 'https://media-assets.swiggy.com/swiggy/image/upload/fl_lossy,f_auto,q_auto,w_660/'

export const RESTURANT_PAGE = 'https://www.swiggy.com/dapi/menu/pl?page-type=REGULAR_MENU&complete-menu=true&lat=12.9160035&lng=77.64267889999999&restaurantId='