import React, { useEffect, useRef, useState } from "react";
import { CDN_URL } from "../utils/constant";

const Section1 = () => {
  const [resList, setResList] = useState([]);
  const scrollRef = useRef(null);

  useEffect(() => {
    fetchRes();
  }, []);

  async function fetchRes() {
    const data = await fetch(
      "https://www.swiggy.com/dapi/restaurants/list/v5?lat=12.9160035&lng=77.64267889999999&is-seo-homepage-enabled=true&page_type=DESKTOP_WEB_LISTING"
    );
    const res = await data.json();
    setResList(res.data.cards[0].card.card.gridElements.infoWithStyle.info);
  }

  const scroll = (direction) => {
    if (scrollRef.current) {
      scrollRef.current.scrollBy({
        left: direction === "left" ? -300 : 300,
        behavior: "smooth",
      });
    }
  };

  return (
    <div className="px-6 py-4 max-w-[1200px] m-auto">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-2xl font-bold mb-4">What's on your mind?</h2>
        <div className="flex">
          {/* Left Arrow */}
          <button
            onClick={() => scroll("left")}
            className="w-8 h-8 bg-gray-300 rounded-full shadow-md flex items-center justify-center text-xl hover:bg-gray-100 mr-4"
          >
            &#8592;
          </button>
          {/* Right Arrow */}
          <button
            onClick={() => scroll("right")}
            className="w-8 h-8 bg-gray-300 rounded-full shadow-md flex items-center justify-center text-xl hover:bg-gray-100"
          >
            &#8594;
          </button>
        </div>
      </div>
      <div className="relative flex items-center bg-gray-100">
        {/* Scrollable Content */}
        <div
          ref={scrollRef}
          className="flex overflow-x-auto gap-6 scrollbar-hide px-12 bg-gray-100"
          style={{ scrollbarWidth: "none", msOverflowStyle: "none" }}
        >
          {resList.map((ele) => (
            <div className="bg-gray-100 flex flex-col items-center flex-shrink-0">
              <img
                src={`${CDN_URL}${ele.imageId}`}
                alt={ele.name}
                className="w-40 h-auto mix-blend-multiply"
              />
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Section1;
