import React, { useState } from "react";
import { useParams } from "react-router-dom";
import Shimer from "./Shimer";
import useResturantMenu from "../utils/useResturantMenu";
import ResturantCategory from "./ResturantCategory";
import { Star, Clock, MapPin, Info } from "lucide-react";
import { CDN_URL } from "../utils/constant";

const ResturantPage = () => {
  const { resId } = useParams();
  const resData = useResturantMenu(resId);
  const [showIndex, setShowIndex] = useState(null);

  if (resData === null) return <Shimer />;

  const { 
    name, 
    city, 
    cuisines, 
    costForTwoMessage, 
    avgRating,
    cloudinaryImageId,
    areaName,
    totalRatingsString,
    sla,
    locality
  } = resData.cards[2].card.card.info;
  console.log(resData)

  const categoryMenu =
    resData.cards[4].groupedCard.cardGroupMap.REGULAR.cards.filter(
      (ele) =>
        ele.card.card["@type"] ==
        "type.googleapis.com/swiggy.presentation.food.v2.ItemCategory"
    );

  return (
    <div className="max-w-4xl mx-auto px-4 py-6">
      {/* Restaurant Header */}
      <div className="bg-white rounded-lg shadow-sm p-6 mb-8">
        <div className="flex flex-col md:flex-row">
          {/* Restaurant Image */}
          <div className="md:w-2/5 h-60 mb-4 md:mb-0 md:mr-6">
            {cloudinaryImageId && (
              <img
                src={`${CDN_URL}${cloudinaryImageId}`}
                alt={name}
                className="w-full h-full object-cover rounded-lg"
              />
            )}
          </div>
          
          {/* Restaurant Details */}
          <div className="md:w-3/5">
            <h1 className="text-2xl font-bold text-gray-800 mb-2">{name}</h1>
            <p className="text-gray-600 mb-3">{cuisines.join(", ")}</p>
            <p className="text-gray-600 mb-4">
              <span className="flex items-center gap-1">
                <MapPin size={16} className="text-gray-400" />
                {locality || areaName}, {city}
              </span>
            </p>
            
            <div className="grid grid-cols-3 gap-4 mb-4">
              {/* Rating */}
              <div className="border-r border-gray-200 pr-4">
                <div className="flex items-center gap-1 mb-1">
                  <div className="text-white bg-green-500 p-1 rounded-full w-8 h-8 flex items-center justify-center">
                    <Star size={16} fill="white" />
                  </div>
                  <span className="font-bold text-lg">{avgRating}</span>
                </div>
                <p className="text-xs text-gray-500">{totalRatingsString || '1000+ ratings'}</p>
              </div>
              
              {/* Delivery Time */}
              <div className="border-r border-gray-200 px-4">
                <div className="flex items-center gap-1 mb-1">
                  <Clock size={18} className="text-gray-700" />
                  <span className="font-bold text-lg">{sla?.slaString || '30 mins'}</span>
                </div>
                <p className="text-xs text-gray-500">Delivery Time</p>
              </div>
              
              {/* Cost */}
              <div className="pl-4">
                <div className="flex items-center gap-1 mb-1">
                  <Info size={18} className="text-gray-700" />
                  <span className="font-bold text-lg">{costForTwoMessage.split(' ')[0]}</span>
                </div>
                <p className="text-xs text-gray-500">Cost for two</p>
              </div>
            </div>
            
            {/* Offer Banners would go here */}
            <div className="bg-gradient-to-r from-orange-100 to-orange-50 p-3 rounded-lg border border-orange-200">
              <p className="text-orange-800 font-medium flex items-center">
                <span className="mr-2">🎁</span>
                50% off up to ₹100 on orders above ₹299
              </p>
            </div>
          </div>
        </div>
      </div>
      
      {/* Menu Categories Section */}
      <div className="bg-white rounded-lg shadow-sm p-4 mb-8">
        <h2 className="text-xl font-bold text-gray-800 mb-6 border-b pb-4">Menu</h2>
        
        <div className="space-y-3">
          {categoryMenu.map((ele, index) => (
            <ResturantCategory
              key={ele.card.card.title}
              data={ele.card.card}
              show={index == showIndex && true}
              setShowIndex={() => setShowIndex(index)}
            />
          ))}
        </div>
      </div>
    </div>
  );
};

export default ResturantPage;