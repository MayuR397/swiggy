import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import ResturantCard, { withResturantPromoted } from "./ResturantCard";
import Shimer from "./Shimer";
import { Search, Filter } from "lucide-react";
// import useOnlineStatus from "../utils/useOnlineStatus";

export default function Body() {
  const [resList, setResList] = useState([]);
  const [filteredResturant, setFilteredResturant] = useState([]);
  const [search, setSearch] = useState("");
  // const onlineStatus = useOnlineStatus();
  const ResturantPromoted = withResturantPromoted(ResturantCard);

  useEffect(() => {
    fetchRes();
  }, []);

  async function fetchRes() {
    const data = await fetch(
      "https://www.swiggy.com/dapi/restaurants/list/v5?lat=12.9160035&lng=77.64267889999999&is-seo-homepage-enabled=true&page_type=DESKTOP_WEB_LISTING"
    );
    const res = await data.json();
    console.log(res.data.cards[1].card);
    setResList(
      res.data.cards[1].card.card.gridElements.infoWithStyle.restaurants
    );
    setFilteredResturant(
      res.data.cards[1].card.card.gridElements.infoWithStyle.restaurants
    );
  }

  // if (onlineStatus == false) return <h1>Looks like you are offline...</h1>;

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      {/* Hero section */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-800 mb-2">
          Hungry? We've got you covered
        </h1>
        <p className="text-gray-600">
          Discover the best food & drinks in Bangalore
        </p>
      </div>

      {/* Search and Filter section */}
      <div className="flex flex-col md:flex-row justify-between items-center mb-8 gap-4">
        <div className="w-full md:w-1/2 relative">
          <div className="flex items-center border border-gray-300 rounded-lg overflow-hidden shadow-sm focus-within:ring-2 focus-within:ring-orange-500 focus-within:border-orange-500">
            <div className="pl-4">
              <Search size={20} className="text-gray-400" />
            </div>
            <input
              className="w-full p-3 outline-none text-gray-700"
              type="text"
              placeholder="Search for restaurants and food"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
            <button
              className="bg-orange-500 hover:bg-orange-600 text-white px-6 py-3 transition duration-300"
              onClick={() => {
                const filteredRes = resList.filter((ele) =>
                  ele.info.name.toLowerCase().includes(search.toLowerCase())
                );
                setFilteredResturant(filteredRes);
              }}
            >
              Search
            </button>
          </div>
        </div>

        <div className="w-full md:w-auto">
          <button
            className="flex items-center gap-2 bg-white border border-gray-300 hover:bg-gray-50 text-gray-700 font-medium py-3 px-4 rounded-lg shadow-sm transition duration-300"
            onClick={() => {
              const filteredData = resList.filter(
                (ele) => ele.info.avgRating > 4.4
              );
              setFilteredResturant(filteredData);
            }}
          >
            <Filter size={16} />
            <span>Top Rated Restaurants</span>
          </button>
        </div>
      </div>

      {/* Restaurant Grid */}
      {filteredResturant.length === 0 ? (
        <Shimer />
      ) : (
        <div>
          <h2 className="text-2xl font-bold text-gray-800 mb-6">
            {filteredResturant.length} restaurants to explore
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {filteredResturant.map((ele) => (
              <Link
                key={ele.info.id}
                to={"resturant/" + ele.info.id}
                className="block transition duration-300 transform hover:-translate-y-1 hover:shadow-lg"
              >
                {ele.info.avgRating >= 4.4 ? (
                  <ResturantPromoted res={ele} />
                ) : (
                  <ResturantCard res={ele} />
                )}
              </Link>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}