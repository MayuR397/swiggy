import Section1 from "./Section1";
import Section2 from "./Section2";
import Body from "./Body";

const Home = () => {
  return (
    <div className="h-screen bg-gray-100">
      <Section1 />
      <hr className="border-t-2 border-gray-200 w-[80%] m-auto mt-6"/>
      <Section2/>
      <hr className="border-t-2 border-gray-200 w-[80%] m-auto mt-6"/>
      <Body/>
    </div>
  );
};

export default Home;
