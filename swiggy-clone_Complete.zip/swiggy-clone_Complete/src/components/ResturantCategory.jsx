import React from "react";
import ItemsList from "./ItemsList";
import { ChevronDown, ChevronUp } from "lucide-react";

const ResturantCategory = ({ data, show, setShowIndex }) => {
  const handleClick = () => {
    setShowIndex();
  };
  
  return (
    <div className="mb-4 mx-auto">
      {/* Category Header/Accordion */}
      <div
        className="flex justify-between items-center p-4 border-b cursor-pointer bg-white hover:bg-gray-50 transition-colors duration-300"
        onClick={handleClick}
      >
        <div className="flex-1">
          <h3 className="font-bold text-lg text-gray-800">
            {data.title} ({data.itemCards?.length})
          </h3>
        </div>
        <div className="text-gray-500">
          {show ? <ChevronUp size={20} /> : <ChevronDown size={20} />}
        </div>
      </div>
      
      {/* Category Items */}
      {show && <ItemsList items={data.itemCards} />}
    </div>
  );
};

export default ResturantCategory;