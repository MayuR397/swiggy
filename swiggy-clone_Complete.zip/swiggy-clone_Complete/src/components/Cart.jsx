import { useDispatch, useSelector } from "react-redux";
import ItemsList from "./ItemsList";
import { removeItems } from "../features/cart/cartSlice";
import { ShoppingBag } from "lucide-react";

const Cart = () => {
  const cartItems = useSelector((store) => store.cart.item);
  const dispatch = useDispatch();

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      {/* Cart Header */}
      <div className="flex justify-between items-center mb-6">
        <div className="flex items-center gap-3">
          <ShoppingBag size={24} className="text-orange-500" />
          <h1 className="text-2xl font-bold text-gray-800">Cart</h1>
          {cartItems.length > 0 && (
            <span className="bg-gray-100 text-gray-700 rounded-full px-2 py-1 text-sm">
              {cartItems.length}
            </span>
          )}
        </div>
        
        <button 
          onClick={() => dispatch(removeItems())}
          className="bg-red-500 hover:bg-red-600 text-white px-4 py-2 rounded-lg font-medium"
        >
          Empty Cart
        </button>
      </div>
      
      {/* Cart Content */}
      <div className="bg-white rounded-lg shadow-sm">
        <div className="w-full">
          <ItemsList items={cartItems} />
        </div>
        
        {/* Checkout Button */}
        {cartItems.length > 0 && (
          <div className="p-4 border-t">
            <button className="w-full bg-green-500 hover:bg-green-600 text-white py-3 rounded-lg font-medium">
              Checkout
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default Cart;