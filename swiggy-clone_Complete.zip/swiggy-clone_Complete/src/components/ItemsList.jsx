import React from "react";
import { CDN_URL } from "../utils/constant";
import { useDispatch } from "react-redux";
import { addItems } from "../features/cart/cartSlice";
import { useLocation } from "react-router-dom";

const ItemsList = ({ items }) => {
  const location = useLocation();
  const isCart = location.pathname === "/cart";
  const dispatch = useDispatch();
  console.log(items);
  function handelAddItems(data) {
    dispatch(addItems(data));
  }
  return (
    <div className="bg-white p-2">
      {items.map((item) => (
        <div
          key={item.card.info.id}
          className="flex justify-between items-center p-4 border-b last:border-0 hover:bg-gray-50"
        >
          {/* Item Info */}
          <div className="flex-1 pr-4">
            {/* Veg/Non-veg Indicator */}
            <div className="mb-1">
              {item.card.info.isVeg ? (
                <div className="w-4 h-4 border border-green-600">
                  <div className="w-2 h-2 rounded-full bg-green-600 m-0.5"></div>
                </div>
              ) : (
                <div className="w-4 h-4 border border-red-600">
                  <div className="w-2 h-2 rounded-full bg-red-600 m-0.5"></div>
                </div>
              )}
            </div>

            {/* Item Name */}
            <h3 className="font-medium text-gray-800 mb-1">
              {item.card.info.name}
            </h3>

            {/* Price */}
            <div className="font-medium text-sm mb-2">
              ₹{item.card.info.price / 100 || item.card.info.defaultPrice / 100}
            </div>

            {/* Description */}
            <p className="text-xs text-gray-500 line-clamp-2">
              {item.card.info.description}
            </p>
          </div>

          {/* Item Image & Add Button */}
          <div className="relative min-w-[118px] h-24">
            {item.card.info.imageId && (
              <img
                src={CDN_URL + item.card.info.imageId}
                className="w-full h-full object-cover rounded-lg"
                alt={item.card.info.name}
              />
            )}

            {/* Add Button */}
            {!isCart && (
              <div className="absolute bottom-0 left-0 right-0 flex justify-center">
                <button
                  onClick={() => handelAddItems(item)}
                  className="bg-white text-green-600 border border-gray-300 px-4 py-1 rounded-md text-sm font-medium shadow-sm hover:bg-gray-50 transform -translate-y-1/2"
                >
                  ADD
                </button>
              </div>
            )}
          </div>
        </div>
      ))}
    </div>
  );
};

export default ItemsList;
