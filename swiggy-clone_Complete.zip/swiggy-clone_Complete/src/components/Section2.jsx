import React, { useEffect, useRef, useState } from "react";
import { CDN_URL } from "../utils/constant";
import { ChevronLeft, ChevronRight, ArrowLeft, ArrowRight } from "lucide-react";

const Section2 = () => {
  const [resList, setResList] = useState([]);
  const scrollRef = useRef(null);

  useEffect(() => {
    fetchRes();
  }, []);

  async function fetchRes() {
    const data = await fetch(
      "https://www.swiggy.com/dapi/restaurants/list/v5?lat=12.9160035&lng=77.64267889999999&is-seo-homepage-enabled=true&page_type=DESKTOP_WEB_LISTING"
    );
    const res = await data.json();
    console.log(
      "Section 2",
      res.data.cards[1].card.card.gridElements.infoWithStyle.restaurants
    );
    setResList(
      res.data.cards[1].card.card.gridElements.infoWithStyle.restaurants
    );
  }

  const scroll = (direction) => {
    if (scrollRef.current) {
      scrollRef.current.scrollBy({
        left: direction === "left" ? -300 : 300,
        behavior: "smooth",
      });
    }
  };

  return (
    <div className="px-6 py-4 max-w-[1200px] m-auto">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-2xl font-bold">
          Top restaurant chains in Bangalore
        </h2>
        <div className="flex gap-2">
          {/* Left Arrow */}
          <button
            onClick={() => scroll("left")}
            className="w-10 h-10 bg-gray-100 rounded-full shadow-sm flex items-center justify-center hover:bg-gray-200"
            aria-label="Scroll left"
          >
            <ArrowLeft size={20} />
          </button>
          {/* Right Arrow */}
          <button
            onClick={() => scroll("right")}
            className="w-10 h-10 bg-gray-100 rounded-full shadow-sm flex items-center justify-center hover:bg-gray-200"
            aria-label="Scroll right"
          >
            <ArrowRight size={20} />
          </button>
        </div>
      </div>

      <div className="relative">
        <div
          ref={scrollRef}
          className="flex overflow-x-auto gap-4 pb-4 scrollbar-hide"
          style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
        >
          {resList.map((ele) => (
            <div
              key={ele.info.id}
              className="flex-shrink-0 w-64 rounded-lg overflow-hidden"
            >
              {/* Image with offer overlay */}
              <div className="relative h-44 rounded-lg overflow-hidden">
                <img
                  src={`${CDN_URL}${ele.info.cloudinaryImageId}`}
                  alt={ele.info.name}
                  className="w-full h-full object-cover"
                />
                {/* Offer text overlay */}
                <div className="absolute bottom-0 left-0 w-full p-2 bg-gradient-to-t from-black to-transparent">
                  <span className="text-white font-bold text-lg">
                    {ele.info.aggregatedDiscountInfoV3?.header || ""}
                  </span>
                </div>
              </div>

              {/* Restaurant details */}
              <div className="p-2">
                <h3 className="text-lg font-semibold truncate">{ele.info.name}</h3>
                
                {/* Rating and delivery time */}
                <div className="flex items-center gap-2 mb-1">
                  <div className="flex items-center">
                    <div className="bg-green-600 text-white p-1 rounded-full w-6 h-6 flex items-center justify-center text-xs">
                      <span>★</span>
                    </div>
                    <span className="ml-1">{ele.info.avgRating}</span>
                  </div>
                  <span className="text-gray-600">•</span>
                  <span className="text-gray-600">{ele.info.sla.slaString}</span>
                </div>

                {/* Cuisines */}
                <p className="text-gray-500 text-sm truncate">
                  {ele.info.cuisines.join(", ")}
                </p>
                
                {/* Area */}
                <p className="text-gray-500 text-sm">{ele.info.areaName}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Section2;