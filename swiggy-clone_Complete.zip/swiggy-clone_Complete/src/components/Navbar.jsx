import {
  Search,
  ShoppingCart,
  HelpCircle,
  ChevronDown,
  User,
  Briefcase,
  Gift,
  House,
} from "lucide-react";
import { useDispatch, useSelector } from "react-redux";
import { Link, useNavigate } from "react-router-dom";
import { logout } from "../features/auth/authSlice";

export default function Navbar() {
  const cartItems = useSelector((state) => state.cart.item);
  const dispatch = useDispatch();
  const navigate = useNavigate();

  const handleLogout = () => {
    dispatch(logout());
    navigate("/login");
  };

  return (
    <nav className="flex items-center justify-between px-6 py-4 border-b border-gray-200 bg-white shadow-sm">
      {/* Logo */}
      <div className="flex items-center">
        <div className="h-10 w-10 rounded-full bg-orange-500 flex items-center justify-center mr-4">
          <House ize={24} className="text-white" />
        </div>

        {/* Location dropdown */}
        <div className="flex items-center">
          <span className="font-semibold">Other</span>
          <ChevronDown size={16} className="ml-1 text-gray-600" />
        </div>
      </div>

      {/* Nav Items */}
      <div className="flex items-center space-x-6">
        {/* Corporate */}
        <div className="flex items-center">
          <Briefcase size={20} className="mr-1" />
          <span>Swiggy Corporate</span>
        </div>

        {/* Search */}
        <div className="flex items-center">
          <Search size={20} className="mr-1" />
          <span>Search</span>
        </div>

        {/* Offers with NEW badge */}
        <div className="flex items-center relative">
          <Gift size={20} className="mr-1" />
          <span className="ml-1">Offers</span>
        </div>

        {/* Help */}
        <div className="flex items-center">
          <HelpCircle size={20} className="mr-1" />
          <span>Help</span>
        </div>

        {/* Sign In */}
        <div className="flex items-center">
          <User size={20} className="mr-1" />
          <span>Sign In</span>
        </div>

        {/* Cart with counter */}
        <Link to="/cart">
          <div className="flex items-center">
            <div className="relative">
              <ShoppingCart size={20} />
              <span className="absolute -top-2 -right-2 bg-white border border-gray-300 rounded-full w-5 h-5 flex items-center justify-center text-xs font-bold">
                {cartItems.length}
              </span>
            </div>
            <span className="ml-1">Cart</span>
          </div>
        </Link>

        <button
          onClick={handleLogout}
          className="px-6 py-2 bg-red-500 text-white rounded hover:bg-red-600 transition"
        >
          Logout
        </button>
      </div>
    </nav>
  );
}
