import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { loginUser } from "../features/auth/authSlice";
import { SWIGGY_LOGO } from "../utils/constant";
import { useNavigate } from "react-router-dom";

const Login = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const { user, loading, error } = useSelector((state) => state.auth);

  const [email, setEmail] = useState("tommy@example.com");
  const [password, setPassword] = useState("123456");
  const [formError, setFormError] = useState("");

  const handleLogin = (e) => {
    e.preventDefault();

    if (!email || !password) {
      setFormError("Please fill out all fields.");
      return;
    }

    if (password.length < 6) {
      setFormError("Password must be at least 6 characters.");
      return;
    }

    setFormError("");
    dispatch(loginUser({ email, password }));
  };

  useEffect(() => {
    if (user) {
      // Login successful
      navigate("/home");
    }
  }, [user, navigate]);

  return (
    <div className="max-w-md mx-auto p-6 bg-white shadow-md rounded-lg">
      {/* Swiggy Logo */}
      <div className="flex justify-center mb-4">
        <img src={SWIGGY_LOGO} alt="Swiggy Logo" className="w-24 h-auto" />
      </div>

      <h2 className="text-2xl font-semibold mb-4 text-center">
        Login to Swiggy
      </h2>
      <form onSubmit={handleLogin}>
        <input
          type="email"
          placeholder="Email"
          className="w-full p-2 mb-4 border border-gray-300 rounded"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
        />
        <input
          type="password"
          placeholder="Password"
          className="w-full p-2 mb-4 border border-gray-300 rounded"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        />
        {formError && (
          <div className="text-red-500 text-sm mb-2">{formError}</div>
        )}
        {error && <div className="text-red-500 text-sm mb-2">{error}</div>}
        <button
          type="submit"
          className="w-full p-2 bg-orange-500 text-white rounded hover:bg-orange-600"
          disabled={loading}
        >
          {loading ? "Logging In..." : "Login"}
        </button>
      </form>
    </div>
  );
};

export default Login;
